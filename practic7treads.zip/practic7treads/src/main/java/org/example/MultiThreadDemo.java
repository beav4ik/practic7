package org.example;

import java.util.Scanner;

public class MultiThreadDemo {
    private boolean stop = false;

    public static void main(String[] args) {
        System.out.println("<<<");
        MultiThreadDemo demo = new MultiThreadDemo();
        demo.start();
    }

    public synchronized void printCurrentThreadName() {
        System.out.println(Thread.currentThread().getName());
    }

    public void start() {
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!stop) {
                    printCurrentThreadName();
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!stop) {
                    printCurrentThreadName();
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        thread1.start();
        thread2.start();
        Scanner sc = new Scanner(System.in);
        while (true) {
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("s")) {
                stop = true;
                break;
            }
        }
    }
}
